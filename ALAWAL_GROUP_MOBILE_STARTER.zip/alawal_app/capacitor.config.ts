import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.alawalgroup.medical',
  appName: 'ALAWAL GROUP',
  webDir: 'www',
  server: {
    url: 'https://lustrous-capybara-9a3d1a.netlify.app/',
    cleartext: false,
    allowNavigation: ['lustrous-capybara-9a3d1a.netlify.app']
  },
  android: {
    allowMixedContent: false
  },
  ios: {
    contentInset: 'automatic'
  }
};

export default config;
